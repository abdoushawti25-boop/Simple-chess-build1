package com.simplechess.app

import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity()
