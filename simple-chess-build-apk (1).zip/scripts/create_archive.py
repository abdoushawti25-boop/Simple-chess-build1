#!/usr/bin/env python3
import os
import zipfile
import shutil

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
OUTPUT_ZIP_PUBLIC = os.path.join(PROJECT_ROOT, 'public', 'simple-chess-source.zip')
OUTPUT_ZIP_ROOT = os.path.join(PROJECT_ROOT, 'simple-chess-source.zip')

EXCLUDE_DIRS = {
    'node_modules',
    '.android-sdk',
    'dist',
    '.git',
    '.gradle',
    'build',
    '__pycache__'
}

EXCLUDE_EXTENSIONS = {
    '.zip',
    '.tar',
    '.gz',
    '.hprof',
    '.class'
}

def should_exclude_dir(dir_name):
    return dir_name in EXCLUDE_DIRS

def should_exclude_file(file_name):
    _, ext = os.path.splitext(file_name)
    return ext.lower() in EXCLUDE_EXTENSIONS

def make_archive(output_path):
    print(f"Creating archive at: {output_path}")
    count = 0
    total_uncompressed_bytes = 0

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    with zipfile.ZipFile(output_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zipf:
        for root, dirs, files in os.walk(PROJECT_ROOT):
            dirs[:] = [d for d in dirs if not should_exclude_dir(d)]

            for file in files:
                if should_exclude_file(file):
                    continue
                
                abs_path = os.path.join(root, file)
                rel_path = os.path.relpath(abs_path, PROJECT_ROOT)
                
                parts = rel_path.split(os.sep)
                if any(p in EXCLUDE_DIRS for p in parts):
                    continue
                if rel_path.endswith('.zip'):
                    continue

                size = os.path.getsize(abs_path)
                total_uncompressed_bytes += size
                zipf.write(abs_path, arcname=rel_path)
                count += 1

    print(f"Archive created: {count} files, size: {os.path.getsize(output_path) / 1024:.1f} KB")
    return count

if __name__ == '__main__':
    file_count = make_archive(OUTPUT_ZIP_ROOT)
    shutil.copy2(OUTPUT_ZIP_ROOT, OUTPUT_ZIP_PUBLIC)
    print(f"Copied to public: {OUTPUT_ZIP_PUBLIC}")
