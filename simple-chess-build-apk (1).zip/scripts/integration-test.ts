import { Chess } from 'chess.js';
import { UCIEngineWorker, AVAILABLE_ENGINES } from '../src/services/engine/chessEngine';
import { lc0NeuralEngine } from '../src/services/engine/lc0NeuralEngine';
import { cheatingDetectionVerificationService } from '../src/services/engine/cheatingDetectionVerificationService';
import { fullGameAnalysisService } from '../src/services/engine/fullGameAnalysisService';
import { eloEstimationService } from '../src/services/engine/eloEstimationService';
import { ponderEngine } from '../src/services/engine/ponderEngine';
import { positionCacheService } from '../src/services/engine/positionCacheService';
import { offlineDiagnosticsService } from '../src/services/engine/offlineDiagnosticsService';
import { HistoryEntry, MoveAnalysis } from '../src/types';

interface TestResult {
  name: string;
  passed: boolean;
  message: string;
}

const results: TestResult[] = [];

function assert(condition: boolean, testName: string, message: string) {
  if (!condition) {
    results.push({ name: testName, passed: false, message });
    console.error(`❌ [FAIL] ${testName}: ${message}`);
  } else {
    results.push({ name: testName, passed: true, message: 'Passed' });
    console.log(`✅ [PASS] ${testName}`);
  }
}

async function runIntegrationSuite() {
  console.log('====================================================');
  console.log('Starting Sirius+ Comprehensive Integration Test Suite');
  console.log('====================================================\n');

  // ----------------------------------------------------
  // TEST 1: Chess rules and move legality
  // ----------------------------------------------------
  console.log('--- 1. Testing Chess Rules & Move Legality ---');
  try {
    const chess = new Chess();
    // Test basic moves
    const m1 = chess.move('e4');
    assert(m1 !== null && m1.san === 'e4', 'Standard move', 'e4 should be legal');
    const m2 = chess.move('e5');
    assert(m2 !== null && m2.san === 'e5', 'Standard reply', 'e5 should be legal');

    // Test illegal move rejection
    let illegalCaught = false;
    try {
      const badMove = chess.move('e5');
      if (!badMove) illegalCaught = true;
    } catch {
      illegalCaught = true;
    }
    assert(illegalCaught, 'Illegal move rejection', 'Moving illegal move should be rejected');

    // Test Castling
    const castlingChess = new Chess('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1');
    const kingsideCastle = castlingChess.move('O-O');
    assert(kingsideCastle !== null, 'White Kingside Castle', 'O-O should be legal');

    // Test En Passant
    const epChess = new Chess('rnbqkbnr/pppp1ppp/8/4pP2/8/8/PPPPP1PP/RNBQKBNR w KQkq e6 0 3');
    const epMove = epChess.move('fxe6');
    assert(epMove !== null && epMove.flags.includes('e'), 'En Passant capture', 'fxe6 should be an en passant capture');

    // Test Promotion
    const promoChess = new Chess('8/4P3/8/8/8/8/8/4K2k w - - 0 1');
    const promoMove = promoChess.move({ from: 'e7', to: 'e8', promotion: 'q' });
    assert(promoMove !== null && promoMove.promotion === 'q', 'Pawn Promotion', 'e8=Q should promote to queen');

    // Test Checkmate detection
    const foolsMateChess = new Chess('rnb1kbnr/pppp1ppp/8/4p3/6Pq/5P2/PPPPP2P/RNBQKBNR w KQkq - 1 3');
    assert(foolsMateChess.isCheckmate(), 'Checkmate detection', 'Position should be recognized as checkmate');
    assert(foolsMateChess.isGameOver(), 'Game over detection', 'Checkmate must be game over');
  } catch (err: any) {
    assert(false, 'Chess rules exception', err?.message || String(err));
  }

  // ----------------------------------------------------
  // TEST 2: Stockfish NNUE Analysis
  // ----------------------------------------------------
  console.log('\n--- 2. Testing Stockfish NNUE Analysis ---');
  try {
    const worker = new UCIEngineWorker('sf-17-nnue');
    assert(worker.getEngine().id === 'sf-17-nnue', 'Engine initialization', 'Should initialize Stockfish 17');
    assert(worker.getEngine().supportsNnue === true, 'NNUE support', 'Stockfish 17 must support NNUE');

    // Test static evaluation
    const startPosEval = worker.evaluateStatic('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
    assert(typeof startPosEval === 'number', 'Static evaluation', 'Static eval should produce numeric score');

    // Test search execution with callback
    let searchCompleted = false;
    let linesReceived = false;
    await worker.search(
      {
        fen: 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1',
        depth: 6,
        multiPv: 2,
        threads: 1,
        hash: 16,
      },
      (lines) => {
        if (lines.length > 0) linesReceived = true;
      },
      () => {
        searchCompleted = true;
      }
    );
    assert(linesReceived, 'Stockfish PV lines', 'Search must stream engine PV lines');
    assert(searchCompleted, 'Stockfish search completion', 'Search must complete successfully');
    worker.stop();
  } catch (err: any) {
    assert(false, 'Stockfish NNUE exception', err?.message || String(err));
  }

  // ----------------------------------------------------
  // TEST 3: Leela Zero Verification
  // ----------------------------------------------------
  console.log('\n--- 3. Testing Leela Zero (Lc0) Verification ---');
  try {
    const testFen = 'r1bqkb1r/pppp1ppp/2n2n2/4p3/4P3/2N2N2/PPPP1PPP/R1BQKB1R w KQkq - 4 4';
    const lc0Result = await lc0NeuralEngine.evaluatePosition(testFen, { nodes: 100 });
    assert(lc0Result !== null, 'Lc0 evaluation return', 'Lc0 evaluatePosition must return result');
    assert(typeof lc0Result.qValue === 'number', 'Lc0 Q-value / evaluation', 'Lc0 must return numeric qValue');
    assert(Array.isArray(lc0Result.topMoves) && lc0Result.topMoves.length > 0, 'Lc0 top moves', 'Lc0 must return move policy list');
    assert(typeof lc0Result.evaluationCp === 'number', 'Lc0 centipawn eval', 'Lc0 must return evaluationCp in centipawns');
    assert(typeof lc0Result.bestMoveSan === 'string' && lc0Result.bestMoveSan.length > 0, 'Lc0 best move SAN', 'Lc0 must identify best SAN move');
  } catch (err: any) {
    assert(false, 'Leela Zero exception', err?.message || String(err));
  }

  // ----------------------------------------------------
  // TEST 4: Cheat-Detection Workflow & Safeguards
  // ----------------------------------------------------
  console.log('\n--- 4. Testing Cheat-Detection Workflow ---');
  try {
    cheatingDetectionVerificationService.resetLog('test_game_1');
    const log = cheatingDetectionVerificationService.getLog();
    assert(log !== null && log.gameHash === 'test_game_1', 'Cheating verification log reset', 'Log must be initialized cleanly');

    // Create a high-complexity tactical move to test screening
    const testFenBefore = 'r1bqkb1r/ppp2ppp/2n2n2/3p4/4P3/2N2N2/PPPP1PPP/R1BQKB1R w KQkq - 0 6';
    const mockMoveAnalysis: MoveAnalysis = {
      moveIndex: 11,
      ply: 12,
      san: 'Nxd5',
      lan: 'c3d5',
      from: 'c3',
      to: 'd5',
      color: 'w',
      fenBefore: testFenBefore,
      fenAfter: 'r1bqkb1r/ppp2ppp/5n2/3N4/4P3/5N2/PPPP1PPP/R1BQKB1R b KQkq - 0 6',
      evalBefore: 20,
      evalAfter: 85,
      evalDiff: 0,
      evalLossCp: 0,
      quality: 'best',
      bestMove: 'c3d5',
      bestMoveSan: 'Nxd5',
      classificationLabel: 'Best Move',
      commentary: 'Precision capture in open center',
      depth: 18,
      nodes: 25000,
    };

    const recorded = cheatingDetectionVerificationService.recordIfSuspicious(mockMoveAnalysis, {
      depth: 18,
      nodes: 25000,
    });

    const currentLog = cheatingDetectionVerificationService.getLog();
    assert(currentLog !== null, 'Verification log state', 'Verification log must be accessible');
    assert(typeof currentLog.totalSuspiciousMoves === 'number', 'Total suspicious moves count', 'totalSuspiciousMoves must be numeric');

    // Verify Leela verification trigger does not crash if offline or empty
    const verifiedLog = await cheatingDetectionVerificationService.verifySuspiciousMovesWithLeela({ nodes: 50 });
    assert(verifiedLog.leelaVerificationCompleted === true, 'Leela verification complete', 'Leela verification must finalize log state');
    assert(typeof verifiedLog.leelaVerificationInProgress === 'boolean', 'Leela in progress check', 'leelaVerificationInProgress must be boolean');
  } catch (err: any) {
    assert(false, 'Cheat detection workflow exception', err?.message || String(err));
  }

  // ----------------------------------------------------
  // TEST 5: Full Game Analysis Lifecycle
  // ----------------------------------------------------
  console.log('\n--- 5. Testing Full Game Analysis Lifecycle ---');
  try {
    const miniMoves = ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5'];
    const testChess = new Chess();
    const history: HistoryEntry[] = [];
    for (const m of miniMoves) {
      const res = testChess.move(m);
      if (res) {
        history.push({
          san: res.san,
          from: res.from,
          to: res.to,
          fen: testChess.fen(),
        });
      }
    }

    let progressSeen = false;
    const unsub = fullGameAnalysisService.subscribe((st) => {
      if (st.progressPercent > 0) progressSeen = true;
    });

    await fullGameAnalysisService.startAnalysis(history, 'sf-17-nnue', false, {
      forceRecompute: true,
      pgnText: '1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5',
    });

    unsub();

    const state = fullGameAnalysisService.getState();
    assert(state.analyzedMoves.length === 6, 'Moves analyzed count', 'All 6 moves must be analyzed');
    assert(state.whiteEloEstimate.estimatedElo > 0, 'White ELO estimation', 'White ELO estimate must be calculated');
    assert(state.blackEloEstimate.estimatedElo > 0, 'Black ELO estimation', 'Black ELO estimate must be calculated');
    assert(state.finalReport !== undefined, 'Final report generated', 'Final report record must be built upon completion');
    assert(state.runningEloHistory.length === 6, 'Running Elo history', 'Running Elo history must have 6 points');
  } catch (err: any) {
    assert(false, 'Full game analysis exception', err?.message || String(err));
  }

  // ----------------------------------------------------
  // TEST 6: Per-Move and Final ELO Estimation
  // ----------------------------------------------------
  console.log('\n--- 6. Testing Per-Move & Final ELO Estimation ---');
  try {
    const sampleMoves: MoveAnalysis[] = [
      {
        moveIndex: 0,
        ply: 1,
        san: 'e4',
        lan: 'e2e4',
        from: 'e2',
        to: 'e4',
        color: 'w',
        fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
        fenAfter: 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1',
        evalBefore: 20,
        evalAfter: 25,
        evalDiff: 5,
        evalLossCp: 0,
        quality: 'best',
        bestMove: 'e2e4',
        bestMoveSan: 'e4',
        classificationLabel: 'Best Move',
        commentary: 'Opening development',
        depth: 14,
      },
      {
        moveIndex: 2,
        ply: 3,
        san: 'Nf3',
        lan: 'g1f3',
        from: 'g1',
        to: 'f3',
        color: 'w',
        fenBefore: 'rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 2',
        fenAfter: 'rnbqkbnr/pppp1ppp/8/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R b KQkq - 1 2',
        evalBefore: 25,
        evalAfter: 30,
        evalDiff: 5,
        evalLossCp: 0,
        quality: 'best',
        bestMove: 'g1f3',
        bestMoveSan: 'Nf3',
        classificationLabel: 'Best Move',
        commentary: 'Developing knight towards center',
        depth: 14,
      },
    ];

    // Progressive rating per-move
    const testPlayer = {
      id: 'test-player-1',
      name: 'Player 1',
      type: 'human' as const,
      initialElo: 1500,
    };
    const testSettings = {
      enabled: true,
      kFactor: 32,
      defaultInitialElo: 1500,
      minMovesForConfidence: 4,
      smoothingWeight: 0.5,
    };
    const whiteRating = eloEstimationService.calculateProgressiveRating('w', testPlayer, sampleMoves, testSettings, 'sf-17-nnue');
    assert(whiteRating.movesPlayed === 2, 'Progressive rating move count', 'Moves played should match input moves');
    assert(whiteRating.currentEstimatedElo >= 500 && whiteRating.currentEstimatedElo <= 3200, 'Estimated Elo bounds', 'Estimated ELO must be in valid chess range');
    assert(whiteRating.accuracy >= 0 && whiteRating.accuracy <= 100, 'Accuracy percentage range', 'Accuracy must be 0-100%');

    // Aggregate stats and final Elo estimation
    const whiteStats = eloEstimationService.computePlayerStats(sampleMoves, 'w');
    assert(whiteStats.totalMoves === 2, 'Player stats move count', 'Stats totalMoves should match');
    assert(whiteStats.bestMoves === 2, 'Best moves count', 'Both sample moves are best');

    const finalElo = eloEstimationService.estimateElo(whiteStats, 'sf-17-nnue');
    assert(finalElo.estimatedElo > 0, 'Final ELO estimation', 'Player must receive non-zero performance ELO');
    assert(typeof finalElo.confidence === 'string', 'Confidence indicator', 'Confidence must be string indicator');
  } catch (err: any) {
    assert(false, 'Elo estimation exception', err?.message || String(err));
  }

  // ----------------------------------------------------
  // TEST 7: Ponder ON / OFF
  // ----------------------------------------------------
  console.log('\n--- 7. Testing Ponder ON/OFF & Settings ---');
  try {
    ponderEngine.updateSettings({ enabled: false });
    assert(!ponderEngine.getSettings().enabled, 'Ponder disabled state', 'Ponder should be disabled');

    ponderEngine.updateSettings({ enabled: true, resourceLimit: 'conservative' });
    assert(ponderEngine.getSettings().enabled, 'Ponder enabled state', 'Ponder should be enabled');

    let listenerCalled = false;
    const unsubscribe = ponderEngine.subscribe((isPondering) => {
      listenerCalled = true;
    });
    assert(listenerCalled, 'Ponder subscription notification', 'Subscriber must be notified on attach');

    await ponderEngine.startPondering('rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1', 'e2e4', 'e7e5');
    const status = ponderEngine.getStatus();
    assert(typeof status.isPondering === 'boolean', 'Pondering status check', 'isPondering must be boolean');

    ponderEngine.stopPondering();
    assert(!ponderEngine.getStatus().isPondering, 'Ponder stopped check', 'isPondering must be false after stop');

    unsubscribe();
    ponderEngine.updateSettings({ enabled: false });
  } catch (err: any) {
    assert(false, 'Ponder engine exception', err?.message || String(err));
  }

  // ----------------------------------------------------
  // TEST 8: Offline Operation & Caching
  // ----------------------------------------------------
  console.log('\n--- 8. Testing Offline Operation & Caching ---');
  try {
    const testFen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
    positionCacheService.set(testFen, {
      engineId: 'sf-17-nnue',
      depth: 14,
      nodes: 12000,
      nps: 50000,
      timeMs: 150,
      evaluationCp: 25,
      bestMove: 'e2e4',
      pvLines: [],
    });

    const cached = positionCacheService.get(testFen);
    assert(cached !== null && cached.bestMove === 'e2e4', 'Position cache hit', 'Cached position must return stored entry');

    const isOnline = offlineDiagnosticsService.getIsOnline();
    assert(typeof isOnline === 'boolean', 'Offline diagnostics network check', 'getIsOnline must return boolean');

    const stressResult = await offlineDiagnosticsService.runFullDeviceStressTest();
    assert(stressResult !== null && typeof stressResult.overallHealthScore === 'number', 'Offline device stress test', 'Stress test must execute and produce numeric score');
  } catch (err: any) {
    assert(false, 'Offline operation exception', err?.message || String(err));
  }

  // ----------------------------------------------------
  // TEST 9: UI ↔ Engine Communication & Orchestration
  // ----------------------------------------------------
  console.log('\n--- 9. Testing UI ↔ Engine Communication ---');
  try {
    const engines = AVAILABLE_ENGINES;
    assert(engines.length >= 4, 'Available engines catalog', 'Must provide multiple engines (SF17, Lc0, Combined, etc.)');

    let fullGameStateNotified = false;
    const unsubState = fullGameAnalysisService.subscribe((st) => {
      if (st) fullGameStateNotified = true;
    });
    assert(fullGameStateNotified, 'Full game analysis UI subscriber', 'UI subscriber must receive analysis state');
    unsubState();

    let cheatingLogNotified = false;
    const unsubCheat = cheatingDetectionVerificationService.subscribe((lg) => {
      if (lg) cheatingLogNotified = true;
    });
    assert(cheatingLogNotified, 'Cheat verification UI subscriber', 'UI subscriber must receive verification log');
    unsubCheat();
  } catch (err: any) {
    assert(false, 'UI ↔ Engine communication exception', err?.message || String(err));
  }

  // ----------------------------------------------------
  // Summary
  // ----------------------------------------------------
  console.log('\n====================================================');
  console.log('Test Suite Finished!');
  const total = results.length;
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  console.log(`Total: ${total} | Passed: ${passed} | Failed: ${failed}`);
  console.log('====================================================');

  if (failed > 0) {
    process.exit(1);
  }
}

runIntegrationSuite().catch((err) => {
  console.error('Fatal error during integration tests:', err);
  process.exit(1);
});
