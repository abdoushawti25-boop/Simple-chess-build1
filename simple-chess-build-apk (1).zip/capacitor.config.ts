import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.simplechess.app',
  appName: 'Simple Chess',
  webDir: 'dist'
};

export default config;
